import { Router } from "./router.js"
import { AuthModel } from "./models/AuthModel.js"
import { StoryModel } from "./models/StoryModel.js"
import { AuthPresenter } from "./presenters/AuthPresenter.js"

class App {
  constructor() {
    this.router = new Router()
    this.authModel = new AuthModel()
    this.storyModel = new StoryModel()
    this.authPresenter = new AuthPresenter(this.authModel)
    this.init()
  }

  init() {
    this.bindNavigationEvents()
    this.updateAuthState()
    this.handleOffline()

    // Initialize router
    this.router.init()
  }

  bindNavigationEvents() {
    // Navigation buttons
    document.getElementById("home-btn")?.addEventListener("click", () => {
      this.navigate("#/")
    })

    document.getElementById("add-btn")?.addEventListener("click", () => {
      this.navigate("#/add")
    })

    document.getElementById("login-btn")?.addEventListener("click", () => {
      this.navigate("#/login")
    })

    document.getElementById("logout-btn")?.addEventListener("click", () => {
      this.logout()
    })
  }

  navigate(hash) {
    window.location.hash = hash
  }

  updateAuthState() {
    const isAuthenticated = this.authModel.isAuthenticated()
    const loginBtn = document.getElementById("login-btn")
    const logoutBtn = document.getElementById("logout-btn")
    const addBtn = document.getElementById("add-btn")

    if (isAuthenticated) {
      loginBtn.style.display = "none"
      logoutBtn.style.display = "block"
      addBtn.style.display = "block"
    } else {
      loginBtn.style.display = "block"
      logoutBtn.style.display = "none"
      addBtn.style.display = "none"
    }
  }

  logout() {
    if (confirm("Apakah Anda yakin ingin logout?")) {
      this.authModel.logout()
      this.updateAuthState()
      this.navigate("#/login")
    }
  }

  handleOffline() {
    window.addEventListener("online", () => {
      console.log("Connection restored")
    })

    window.addEventListener("offline", () => {
      console.log("Connection lost")
    })
  }
}

// Initialize app when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  window.app = new App()
})
