export class LoginView {
  render(isLoginMode) {
    return `
      <div class="login-page">
        <div class="form-container">
          <div class="auth-header">
            <h2 id="form-title">🔐 ${isLoginMode ? "Masuk" : "Daftar"}</h2>
            <p class="auth-subtitle">
              ${isLoginMode ? "Masuk ke akun Dicoding Story Anda" : "Buat akun baru untuk berbagi cerita"}
            </p>
          </div>
          
          <form id="auth-form">
            <div class="form-group" id="name-group" style="display: ${isLoginMode ? "none" : "block"}">
              <label for="name">Nama Lengkap *</label>
              <input 
                type="text" 
                id="name" 
                name="name" 
                placeholder="Masukkan nama lengkap Anda"
                ${!isLoginMode ? "required" : ""}
              >
            </div>
            
            <div class="form-group">
              <label for="email">Email *</label>
              <input 
                type="email" 
                id="email" 
                name="email" 
                required
                placeholder="contoh@email.com"
              >
            </div>
            
            <div class="form-group">
              <label for="password">Password *</label>
              <input 
                type="password" 
                id="password" 
                name="password" 
                required
                placeholder="Minimal 8 karakter"
                minlength="8"
              >
              <small>Password harus minimal 8 karakter</small>
            </div>
            
            <button type="submit" class="btn btn-primary" id="submit-btn">
              ${isLoginMode ? "Masuk" : "Daftar"}
            </button>
          </form>
          
          <div class="auth-footer">
            <p>
              ${isLoginMode ? "Belum punya akun?" : "Sudah punya akun?"}
              <button 
                type="button" 
                id="toggle-mode" 
                class="link-btn"
              >
                ${isLoginMode ? "Daftar di sini" : "Masuk di sini"}
              </button>
            </p>
          </div>
        </div>
      </div>
    `
  }
}
