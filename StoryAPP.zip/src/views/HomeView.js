import { formatDate } from "../utils/helpers.js"

export class HomeView {
  render() {
    return `
      <div class="home-page">
        <div class="stories-header">
          <div class="header-content">
            <h2>📚 Daftar Cerita</h2>
            <p class="text-light">Jelajahi cerita-cerita menarik dari komunitas</p>
          </div>
          <div class="view-controls">
            <button id="grid-view-btn" class="view-btn active">
              📋 Grid
            </button>
            <button id="map-view-btn" class="view-btn">
              🗺️ Map
            </button>
          </div>
        </div>
        
        <!-- Grid View -->
        <div id="grid-view" class="view-container">
          <div id="stories-container" class="stories-grid">
            <!-- Stories will be loaded here -->
          </div>
        </div>
        
        <!-- Map View -->
        <div id="map-view" class="view-container" style="display: none;">
          <div class="map-container">
            <div id="stories-map" class="stories-map"></div>
            <div class="map-info">
              <p>📍 Klik marker untuk melihat detail cerita</p>
              <button id="my-location-btn" class="btn btn-secondary btn-small">
                🎯 Lokasi Saya
              </button>
            </div>
          </div>
        </div>
      </div>
    `
  }

  renderStoryCard(story) {
    const hasLocation = story.lat && story.lon

    return `
      <div class="story-card" data-story-id="${story.id}">
        <img 
          src="${story.photoUrl}" 
          alt="${story.name || "Story photo"}"
          class="story-image"
          loading="lazy"
          onerror="this.src='/placeholder.svg?height=200&width=300'"
        >
        <div class="story-content">
          <h3 class="story-title">${story.name || "Anonymous"}</h3>
          <p class="story-description">${story.description}</p>
          <div class="story-meta">
            <span class="story-date">${formatDate(story.createdAt)}</span>
            ${hasLocation ? '<span class="story-location">📍 Lokasi tersedia</span>' : ""}
          </div>
        </div>
      </div>
    `
  }
}
