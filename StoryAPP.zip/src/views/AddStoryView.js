export class AddStoryView {
  render() {
    return `
      <div class="add-story-page">
        <div class="form-container">
          <h2>➕ Tambah Cerita Baru</h2>
          <form id="add-story-form">
            <div class="form-group">
              <label for="story-description">Deskripsi Cerita *</label>
              <textarea 
                id="story-description" 
                name="description" 
                required
                placeholder="Ceritakan pengalaman Anda di Dicoding..."
                maxlength="500"
              ></textarea>
              <small>Maksimal 500 karakter</small>
            </div>
            
            <div class="form-group">
              <label>Foto *</label>
              <div class="photo-input-container">
                <div class="photo-input-buttons">
                  <button type="button" id="camera-btn" class="btn btn-secondary">
                    📷 Buka Kamera
                  </button>
                  <button type="button" id="gallery-btn" class="btn btn-secondary">
                    🖼️ Pilih dari Galeri
                  </button>
                </div>
                <input 
                  type="file" 
                  id="story-photo" 
                  name="photo" 
                  accept="image/jpeg,image/jpg,image/png"
                  style="display: none;"
                >
              </div>
              <small>Format: JPEG, JPG, PNG. Maksimal 1MB</small>
            </div>
            
            <!-- Camera Modal -->
            <div id="camera-modal" class="camera-modal" style="display: none;">
              <div class="camera-modal-content">
                <div class="camera-header">
                  <h3>📷 Ambil Foto</h3>
                  <button type="button" id="close-camera" class="close-btn">&times;</button>
                </div>
                <div class="camera-container">
                  <video id="camera-video" autoplay playsinline></video>
                  <canvas id="camera-canvas" style="display: none;"></canvas>
                </div>
                <div class="camera-controls">
                  <button type="button" id="switch-camera" class="btn btn-secondary">
                    🔄 Ganti Kamera
                  </button>
                  <button type="button" id="capture-photo" class="btn">
                    📸 Ambil Foto
                  </button>
                </div>
              </div>
            </div>
            
            <div id="photo-preview" class="photo-preview"></div>

            <!-- Location Map - langsung muncul -->
            <div id="location-map-container" class="location-map-container" style="display: block;">
              <div class="map-header">
                <h4>📍 Pilih Lokasi di Peta</h4>
                <div class="map-controls-header">
                  <button type="button" id="use-current-location" class="btn btn-secondary btn-small">
                    🎯 Gunakan Lokasi Saat Ini
                  </button>
                  <button type="button" id="close-map" class="close-btn">&times;</button>
                </div>
              </div>
              <div id="location-map" class="location-map"></div>
              <div class="map-controls">
                <div id="location-info" class="location-info-inline">
                  <p>📍 <span id="location-text">Klik pada peta untuk memilih lokasi</span></p>
                </div>
              </div>
              <small>Klik pada peta untuk memilih lokasi, atau seret marker merah untuk mengubah posisi</small>
            </div>
            
            <div class="form-actions">
              <button type="button" class="btn btn-secondary" onclick="window.location.hash = '#/'">
                Batal
              </button>
              <button type="submit" class="btn" id="submit-btn">
                Tambah Cerita
              </button>
            </div>
          </form>
        </div>
      </div>
    `
  }
}
