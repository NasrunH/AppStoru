import { LoginView } from "../views/LoginView.js"
import { showLoading, hideLoading, showMessage, validateEmail } from "../utils/helpers.js"

export class LoginPresenter {
  constructor(authModel, storyModel) {
    this.authModel = authModel
    this.storyModel = storyModel
    this.view = new LoginView()
    this.isLoginMode = true
  }

  async init() {
    await this.render()
    this.bindEvents()
  }

  async render() {
    const content = this.view.render(this.isLoginMode)
    document.getElementById("page-content").innerHTML = content
  }

  bindEvents() {
    const form = document.getElementById("auth-form")
    const toggleBtn = document.getElementById("toggle-mode")
    const submitBtn = document.getElementById("submit-btn")

    form.addEventListener("submit", async (e) => {
      e.preventDefault()
      await this.handleSubmit(e, submitBtn)
    })

    toggleBtn.addEventListener("click", () => {
      this.toggleMode()
    })
  }

  toggleMode() {
    this.isLoginMode = !this.isLoginMode
    this.render()
    this.bindEvents()
  }

  async handleSubmit(e, submitBtn) {
    const formData = new FormData(e.target)
    const email = formData.get("email").trim()
    const password = formData.get("password").trim()
    const name = formData.get("name")?.trim()

    // Validation
    if (!validateEmail(email)) {
      showMessage("Format email tidak valid")
      return
    }

    if (password.length < 8) {
      showMessage("Password minimal 8 karakter")
      return
    }

    if (!this.isLoginMode && (!name || name.length < 2)) {
      showMessage("Nama harus diisi minimal 2 karakter")
      return
    }

    try {
      submitBtn.disabled = true
      submitBtn.textContent = this.isLoginMode ? "Masuk..." : "Mendaftar..."
      showLoading()

      if (this.isLoginMode) {
        const response = await this.authModel.login(email, password)
        showMessage(`Selamat datang, ${response.loginResult.name}! 🎉`, "success")
        window.app.updateAuthState()

        // Auto redirect to home
        setTimeout(() => {
          window.location.hash = "#/"
        }, 1000)
      } else {
        await this.authModel.register(name, email, password)
        showMessage("Pendaftaran berhasil! Silakan masuk dengan akun Anda.", "success")

        // Switch to login mode after successful registration
        setTimeout(() => {
          this.isLoginMode = true
          this.toggleMode()
          // Pre-fill email
          document.getElementById("email").value = email
        }, 2000)
      }
    } catch (error) {
      console.error("Auth error:", error)
      let errorMessage = error.message

      // Handle specific error messages
      if (errorMessage.includes("User not found")) {
        errorMessage = "Email tidak terdaftar. Silakan daftar terlebih dahulu."
      } else if (errorMessage.includes("Invalid password")) {
        errorMessage = "Password salah. Silakan coba lagi."
      } else if (errorMessage.includes("Email is already taken")) {
        errorMessage = "Email sudah terdaftar. Silakan gunakan email lain atau masuk."
      }

      showMessage(errorMessage)
    } finally {
      submitBtn.disabled = false
      submitBtn.textContent = this.isLoginMode ? "Masuk" : "Daftar"
      hideLoading()
    }
  }
}
