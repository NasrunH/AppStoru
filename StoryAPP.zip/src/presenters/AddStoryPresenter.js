import { AddStoryView } from "../views/AddStoryView.js"
import { showLoading, hideLoading, showMessage, validateFile } from "../utils/helpers.js"
import { MapManager } from "../utils/maps.js"

export class AddStoryPresenter {
  constructor(authModel, storyModel) {
    this.authModel = authModel
    this.storyModel = storyModel
    this.view = new AddStoryView()
    this.selectedFile = null
    this.currentLocation = null
    this.stream = null
    this.isCameraMode = false
    this.mapManager = new MapManager()
    this.showMap = false
  }

  async init() {
    await this.render()
    // Langsung tampilkan peta lokasi dan ambil lokasi saat ini
    this.showLocationMap()
    this.getCurrentLocation()
    this.bindEvents()
  }

  async render() {
    const content = this.view.render()
    document.getElementById("page-content").innerHTML = content
  }

  bindEvents() {
    const form = document.getElementById("add-story-form")
    const photoInput = document.getElementById("story-photo")
    const cameraBtn = document.getElementById("camera-btn")
    const galleryBtn = document.getElementById("gallery-btn")
    const submitBtn = document.getElementById("submit-btn")

    // Camera controls
    const cameraModal = document.getElementById("camera-modal")
    const closeCameraBtn = document.getElementById("close-camera")
    const switchCameraBtn = document.getElementById("switch-camera")
    const captureBtn = document.getElementById("capture-photo")

    // Map controls
    const closeMapBtn = document.getElementById("close-map")
    const useCurrentLocationBtn = document.getElementById("use-current-location")

    // Gallery button
    galleryBtn?.addEventListener("click", () => {
      photoInput.click()
    })

    // Camera button
    cameraBtn?.addEventListener("click", () => {
      this.openCamera()
    })

    // Close camera
    closeCameraBtn?.addEventListener("click", () => {
      this.closeCamera()
    })

    // Switch camera
    switchCameraBtn?.addEventListener("click", () => {
      this.switchCamera()
    })

    // Capture photo
    captureBtn?.addEventListener("click", () => {
      this.capturePhoto()
    })

    // Close modal when clicking outside
    cameraModal?.addEventListener("click", (e) => {
      if (e.target === cameraModal) {
        this.closeCamera()
      }
    })

    // Map controls
    closeMapBtn?.addEventListener("click", () => {
      this.hideLocationMap()
      // Checkbox sudah dihapus, jadi tidak perlu set unchecked
    })

    useCurrentLocationBtn?.addEventListener("click", () => {
      this.getCurrentLocation()
    })

    // Photo input change
    photoInput?.addEventListener("change", (e) => {
      const file = e.target.files[0]
      if (file) {
        this.handleFileSelect(file)
      }
    })

    // Form submission
    form?.addEventListener("submit", async (e) => {
      e.preventDefault()
      await this.handleSubmit(e, submitBtn)
    })

    // Character counter for description
    const descriptionTextarea = document.getElementById("story-description")
    descriptionTextarea?.addEventListener("input", (e) => {
      const remaining = 500 - e.target.value.length
      const small = e.target.parentNode.querySelector("small")
      small.textContent = `${remaining} karakter tersisa`
      small.style.color = remaining < 50 ? "#ef4444" : "#6b7280"
    })

    // Handle escape key to close camera/map
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        if (this.isCameraMode) {
          this.closeCamera()
        } else if (this.showMap) {
          this.hideLocationMap()
        }
      }
    })
  }

  showLocationMap() {
    const mapContainer = document.getElementById("location-map-container")
    mapContainer.style.display = "block"
    this.showMap = true

    setTimeout(() => {
      if (!this.mapManager.map) {
        this.mapManager.initMap("location-map", {
          center: [-2.5489, 118.0149], // Default ke Indonesia
          zoom: 5,
        })

        this.mapManager.onMapClick((lat, lon) => {
          this.currentLocation = { lat, lon }
          this.mapManager.addUserLocation(lat, lon, {
            draggable: true,
            title: "Seret untuk mengubah lokasi",
          })

          this.mapManager.setUserLocationDraggable((newLat, newLon) => {
            this.currentLocation = { lat: newLat, lon: newLon }
            this.updateLocationText()
          })

          this.updateLocationText()
          showMessage("Lokasi berhasil dipilih! 📍", "success")
        })
      }
    }, 100)
  }

  hideLocationMap() {
    const mapContainer = document.getElementById("location-map-container")
    mapContainer.style.display = "none"
    this.showMap = false
  }

  async getCurrentLocation() {
    const locationText = document.getElementById("location-text")

    if (!navigator.geolocation) {
      locationText.textContent = "Geolocation tidak didukung - pilih lokasi di peta"
      return
    }

    locationText.textContent = "Mendapatkan lokasi saat ini..."

    navigator.geolocation.getCurrentPosition(
      (position) => {
        this.currentLocation = {
          lat: position.coords.latitude,
          lon: position.coords.longitude,
        }

        if (this.mapManager.map) {
          this.mapManager.centerOnLocation(this.currentLocation.lat, this.currentLocation.lon, 15)
          this.mapManager.addUserLocation(this.currentLocation.lat, this.currentLocation.lon, {
            draggable: true,
            title: "Seret untuk mengubah lokasi",
          })

          this.mapManager.setUserLocationDraggable((lat, lon) => {
            this.currentLocation = { lat, lon }
            this.updateLocationText()
          })
        }

        this.updateLocationText()
        showMessage("Lokasi saat ini berhasil ditemukan! 📍", "success")
      },
      (error) => {
        console.error("Geolocation error:", error)
        locationText.textContent = "Gagal mendapatkan lokasi - pilih lokasi di peta"
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000,
      },
    )
  }

  updateLocationText() {
    const locationText = document.getElementById("location-text")
    if (this.currentLocation && locationText) {
      locationText.textContent = `Lat: ${this.currentLocation.lat.toFixed(6)}, Lon: ${this.currentLocation.lon.toFixed(6)}`
    }
  }

  async openCamera() {
    const cameraModal = document.getElementById("camera-modal")
    const video = document.getElementById("camera-video")

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Kamera tidak didukung di browser ini")
      }

      cameraModal.style.display = "flex"
      this.isCameraMode = true

      this.stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "environment",
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      })

      video.srcObject = this.stream
      await video.play()

      showMessage("Kamera berhasil dibuka! 📷", "success")
    } catch (error) {
      console.error("Camera error:", error)
      this.closeCamera()

      let errorMessage = "Gagal membuka kamera"
      if (error.name === "NotAllowedError") {
        errorMessage = "Akses kamera ditolak. Silakan izinkan akses kamera di browser."
      } else if (error.name === "NotFoundError") {
        errorMessage = "Kamera tidak ditemukan di device ini."
      } else if (error.name === "NotSupportedError") {
        errorMessage = "Kamera tidak didukung di browser ini."
      } else {
        errorMessage = `Gagal membuka kamera: ${error.message}`
      }

      showMessage(errorMessage)
    }
  }

  async switchCamera() {
    if (!this.stream) return

    const video = document.getElementById("camera-video")
    const currentTrack = this.stream.getVideoTracks()[0]
    const currentFacingMode = currentTrack.getSettings().facingMode

    try {
      this.stream.getTracks().forEach((track) => track.stop())

      const newFacingMode = currentFacingMode === "environment" ? "user" : "environment"

      this.stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: newFacingMode,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      })

      video.srcObject = this.stream
      await video.play()

      showMessage(`Beralih ke kamera ${newFacingMode === "environment" ? "belakang" : "depan"}`, "success")
    } catch (error) {
      console.error("Switch camera error:", error)
      showMessage("Gagal mengganti kamera")

      try {
        this.stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: currentFacingMode,
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
          audio: false,
        })
        video.srcObject = this.stream
      } catch (fallbackError) {
        this.closeCamera()
      }
    }
  }

  capturePhoto() {
    const video = document.getElementById("camera-video")
    const canvas = document.getElementById("camera-canvas")
    const context = canvas.getContext("2d")

    if (!video.videoWidth || !video.videoHeight) {
      showMessage("Video belum siap. Tunggu sebentar.")
      return
    }

    const maxWidth = 1024
    const maxHeight = 768

    let { videoWidth, videoHeight } = video

    if (videoWidth > maxWidth || videoHeight > maxHeight) {
      const ratio = Math.min(maxWidth / videoWidth, maxHeight / videoHeight)
      videoWidth *= ratio
      videoHeight *= ratio
    }

    canvas.width = videoWidth
    canvas.height = videoHeight

    context.drawImage(video, 0, 0, videoWidth, videoHeight)

    canvas.toBlob(
      (blob) => {
        if (blob) {
          if (blob.size > 1024 * 1024) {
            showMessage("Foto terlalu besar. Coba ambil foto dengan resolusi lebih kecil.")
            return
          }

          const file = new File([blob], `camera-photo-${Date.now()}.jpg`, {
            type: "image/jpeg",
          })

          this.handleFileSelect(file)
          this.closeCamera()
          showMessage("Foto berhasil diambil! 📸", "success")
        } else {
          showMessage("Gagal mengambil foto")
        }
      },
      "image/jpeg",
      0.7,
    )
  }

  closeCamera() {
    const cameraModal = document.getElementById("camera-modal")

    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop())
      this.stream = null
    }

    cameraModal.style.display = "none"
    this.isCameraMode = false
  }

  handleFileSelect(file) {
    try {
      validateFile(file)
      this.selectedFile = file
      this.showPhotoPreview(file)
    } catch (error) {
      showMessage(error.message)
      this.selectedFile = null
      this.clearPhotoPreview()
    }
  }

  showPhotoPreview(file) {
    const preview = document.getElementById("photo-preview")
    const reader = new FileReader()

    reader.onload = (e) => {
      preview.innerHTML = `
        <div class="preview-container">
          <img 
            src="${e.target.result}" 
            alt="Preview" 
            class="preview-image"
          >
          <div class="preview-info">
            <p><strong>${file.name}</strong></p>
            <p>Ukuran: ${(file.size / 1024).toFixed(1)} KB</p>
            <button type="button" class="btn btn-secondary btn-small" onclick="this.parentElement.parentElement.parentElement.innerHTML = ''; window.app.router.currentPresenter.selectedFile = null;">
              🗑️ Hapus
            </button>
          </div>
        </div>
      `
    }

    reader.readAsDataURL(file)
  }

  clearPhotoPreview() {
    const preview = document.getElementById("photo-preview")
    preview.innerHTML = ""
  }

  async handleSubmit(e, submitBtn) {
    const formData = new FormData(e.target)
    const description = formData.get("description").trim()

    if (!description) {
      showMessage("Deskripsi cerita harus diisi")
      return
    }

    if (!this.selectedFile) {
      showMessage("Foto harus dipilih atau diambil")
      return
    }

    try {
      submitBtn.disabled = true
      submitBtn.textContent = "Menambahkan..."
      showLoading()

      const response = await this.storyModel.addStory(
        description,
        this.selectedFile,
        this.currentLocation?.lat,
        this.currentLocation?.lon,
      )

      showMessage("Cerita berhasil ditambahkan! 🎉", "success")

      // Reset form
      e.target.reset()
      this.selectedFile = null
      this.currentLocation = null
      this.clearPhotoPreview()
      document.getElementById("location-info").style.display = "none"
      this.hideLocationMap()

      // Navigate to home after 2 seconds
      setTimeout(() => {
        window.location.hash = "#/"
      }, 2000)
    } catch (error) {
      console.error("❌ Error adding story:", error)

      let errorMessage = "Gagal menambahkan cerita"

      if (error.message.includes("400")) {
        errorMessage = "Data yang dikirim tidak valid. Periksa format foto dan deskripsi."
      } else if (error.message.includes("401")) {
        errorMessage = "Sesi Anda telah berakhir. Silakan login kembali."
        this.authModel.logout()
        window.app.updateAuthState()
        window.location.hash = "#/login"
        return
      } else if (error.message.includes("413")) {
        errorMessage = "Ukuran foto terlalu besar. Maksimal 1MB."
      } else if (error.message.includes("422")) {
        errorMessage = "Format foto tidak didukung. Gunakan JPEG, JPG, atau PNG."
      } else {
        errorMessage = `Gagal menambahkan cerita: ${error.message}`
      }

      showMessage(errorMessage)
    } finally {
      submitBtn.disabled = false
      submitBtn.textContent = "Tambah Cerita"
      hideLoading()
    }
  }

  cleanup() {
    this.closeCamera()
    if (this.mapManager) {
      this.mapManager.destroy()
    }
  }
}
