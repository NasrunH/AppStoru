import { HomePresenter } from "./presenters/HomePresenter.js"
import { AddStoryPresenter } from "./presenters/AddStoryPresenter.js"
import { LoginPresenter } from "./presenters/LoginPresenter.js"
import { AuthModel } from "./models/AuthModel.js"
import { StoryModel } from "./models/StoryModel.js"

export class Router {
  constructor() {
    this.routes = {
      "/": HomePresenter,
      "/add": AddStoryPresenter,
      "/login": LoginPresenter,
    }

    this.currentPresenter = null
    this.authModel = new AuthModel()
    this.storyModel = new StoryModel()
  }

  init() {
    // Handle hash change
    window.addEventListener("hashchange", () => {
      this.loadPage()
    })

    // Load initial page
    this.loadPage()
  }

  async loadPage() {
    // Get hash without #
    const hash = window.location.hash.slice(1) || "/"

    // Cleanup previous presenter
    if (this.currentPresenter && typeof this.currentPresenter.cleanup === "function") {
      this.currentPresenter.cleanup()
    }

    // Check authentication for protected routes
    if ((hash === "/" || hash === "/add") && !this.authModel.isAuthenticated()) {
      window.location.hash = "#/login"
      return
    }

    if (hash === "/login" && this.authModel.isAuthenticated()) {
      window.location.hash = "#/"
      return
    }

    // Default to home if path not found
    const PresenterClass = this.routes[hash] || this.routes["/"]

    try {
      // Create presenter with models
      this.currentPresenter = new PresenterClass(this.authModel, this.storyModel)

      // Initialize presenter
      await this.currentPresenter.init()

      // Update navigation
      this.updateNavigation(hash)
    } catch (error) {
      console.error("Error loading page:", error)
      document.getElementById("page-content").innerHTML = `
        <div class="error">
          <h2>Oops! Terjadi kesalahan</h2>
          <p>${error.message}</p>
        </div>
      `
    }
  }

  updateNavigation(currentPath) {
    // Remove active class from all nav buttons
    document.querySelectorAll(".nav-btn").forEach((btn) => {
      btn.classList.remove("active")
    })

    // Add active class to current page button
    const pathToButton = {
      "/": "home-btn",
      "/add": "add-btn",
      "/login": "login-btn",
    }

    const activeBtn = document.getElementById(pathToButton[currentPath])
    if (activeBtn) {
      activeBtn.classList.add("active")
    }
  }
}
