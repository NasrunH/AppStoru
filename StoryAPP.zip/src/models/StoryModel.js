export class StoryModel {
  constructor() {
    this.baseURL = "https://story-api.dicoding.dev/v1"
    this.stories = []
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`
    const config = {
      ...options,
    }

    // Add Authorization header if token exists and not skipped
    const token = localStorage.getItem("token")
    if (token && !options.skipAuth) {
      config.headers = {
        ...config.headers,
        Authorization: `Bearer ${token}`,
      }
    }

    // Add Content-Type for JSON requests
    if (options.body && typeof options.body === "string") {
      config.headers = {
        "Content-Type": "application/json",
        ...config.headers,
      }
    }

    try {
      const response = await fetch(url, config)

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`HTTP ${response.status}: ${response.statusText}`)
      }

      const contentType = response.headers.get("content-type")
      if (!contentType || !contentType.includes("application/json")) {
        const responseText = await response.text()
        throw new Error("Server returned non-JSON response")
      }

      const data = await response.json()

      if (data.error === true) {
        throw new Error(data.message || "API returned an error")
      }

      return data
    } catch (error) {
      if (error.name === "TypeError" && error.message.includes("fetch")) {
        throw new Error("Tidak dapat terhubung ke server. Periksa koneksi internet Anda.")
      }

      if (error.name === "SyntaxError") {
        throw new Error("Server mengembalikan response yang tidak valid.")
      }

      throw error
    }
  }

  async getStories(page = 1, size = 20, location = 1) {
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        size: size.toString(),
        location: location.toString(),
      })

      const response = await this.request(`/stories?${params}`)

      if (response && response.data && response.data.listStory) {
        this.stories = response.data.listStory
        return response
      }

      if (response.listStory) {
        this.stories = response.listStory
        return {
          error: false,
          message: "Stories fetched successfully",
          data: {
            listStory: response.listStory,
          },
        }
      }

      if (response.data && Array.isArray(response.data)) {
        this.stories = response.data
        return {
          error: false,
          message: "Stories fetched successfully",
          data: {
            listStory: response.data,
          },
        }
      }

      this.stories = []
      return {
        error: false,
        message: "Stories fetched successfully",
        data: {
          listStory: [],
        },
      }
    } catch (error) {
      console.error("❌ Error in getStories:", error)
      throw error
    }
  }

  async getStoryDetail(id) {
    return await this.request(`/stories/${id}`)
  }

  async addStory(description, photo, lat = null, lon = null) {
    try {
      const formData = new FormData()
      formData.append("description", description)
      formData.append("photo", photo)

      if (lat !== null && lon !== null) {
        formData.append("lat", lat.toString())
        formData.append("lon", lon.toString())
      }

      return await this.request("/stories", {
        method: "POST",
        body: formData,
      })
    } catch (error) {
      console.error("❌ Error in addStory:", error)
      throw error
    }
  }

  async testConnection() {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch(this.baseURL + "/stories", {
        method: "HEAD",
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      })
      return response.ok
    } catch (error) {
      return false
    }
  }

  getStoriesData() {
    return this.stories
  }
}
